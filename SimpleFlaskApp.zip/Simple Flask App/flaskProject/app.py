from flask import Flask, render_template
from os import environ
app = Flask(__name__)

# Resume data structure
resume_data = {
    "name": "Brian D. Giangiordano",
    "title": "CDMP, PCM® | PCEP Python Certified",
    "contact": {
        "email": "bgiangiordano@gmail.com",
        "phone": "567.208.9826",
        "address": "338 Utah Avenue, Findlay, Ohio, 45840"
    },
    "education": [{
        "school": "University of Cincinnati, Lindner College of Business",
        "location": "Cincinnati, Ohio",
        "degree": "Bachelor of Business Administration, Marketing",
        "graduation": "April 2014"
    }],
    "experience": [
        {
            "company": "AR Marketing",
            "location": "Findlay, Ohio",
            "roles": [
                {
                    "title": "On-site Marketing Manager",
                    "period": "April 2024 - Present"
                },
                {
                    "title": "On-site Marketing Coordinator",
                    "period": "April 2020 - April 2024"
                }
            ],
            "highlights": [
                "Developed & executed campaign strategies, receiving back-to-back NGA Creative Choice Awards (2022-2023).",
                "Managed marketing projects for 95 stores ensuring timely execution & cross-departmental alignment.",
                "Increased donation campaigns by 64%, significantly enhancing brand visibility and customer engagement.",
                "Consolidated print ad distribution, resulting in $93,000+ of annual savings",
                "Supervised seasonal interns, driving initiatives that contributed to a 110% increase in Local Food Fest attendance."
            ]
        },
        # Add other experience entries similarly
    ],
    "skills": {
        "Marketing & Design": ["Adobe Creative Cloud (Photoshop, InDesign, Illustrator)", "HubSpot", "Mailchimp"],
        "Data & Analytics": ["MITS BI", "Google Analytics (GA4)", "Google Search Console", "Ecount ERP", "BRdata"],
        "CRM & Sales": ["Salesforce", "Tour De Force CRM", "Zendesk", "LinkedIn Sales Navigator"],
        "AI & Development": ["ChatGPT", "Claude", "Ollama", "Python", "PyCharm", "Visual Studio Code", "GitHub"],
        "Project Management": ["Monday.com", "Asana"]
    },
    "certifications": [
        "Certified Digital Marketing Pro | Digital Marketing Institute -- 2024",
        "Certified Marketer | American Marketing Association -- 2024",
        "PCEP-30-02 Certified Entry-Level Python Programmer | Python Institute -- 2024",
        "Creative Choice Awards Team Winner: Community Engagement | NGA -- 2023",
        "Hancock Leadership Program | Hancock County Chamber of Commerce -- 2023",
        "2X Creative Choice Awards Team Winner: Kellogg's Supermarket Superheroes & Traditional Media | NGA -- 2022"
    ]
}

@app.route('/')
def home():
    return render_template('resume.html', resume=resume_data)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=environ.get('PORT', 5000))